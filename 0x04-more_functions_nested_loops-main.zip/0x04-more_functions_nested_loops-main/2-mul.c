#include "main.h"
/**
 * mul - multiply 2 int
 * @a: first int
 * @b: second int
 * Return: addition of the multiplicattion
 */

int mul(int a, int b)
{
	return (a * b);
}
